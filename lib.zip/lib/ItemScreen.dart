// import 'package:flutter/src/widgets/framework.dart';
// import 'package:flutter/src/widgets/placeholder.dart';

import 'package:flutter/material.dart';
import 'package:flutter_application_3/ShoppingList.dart';
// import 'package:provider/provider.dart';
// import 'package:flutter_application_3/MyProvider.dart';

class ItemsScreen extends StatefulWidget {
  final ShoppingList shoppingList;
  const ItemsScreen(this.shoppingList);

  @override
  _ItemsScreenState createState() => _ItemsScreenState(this.shoppingList);
}

class _ItemsScreenState extends State<ItemsScreen> {
  final ShoppingList shoppingList;
  _ItemsScreenState(this.shoppingList);
  @override
  Widget build(BuildContext context) {
    // var prov = Provider.of<ListProductProvider>(context, listen: true);
    return Scaffold(
      appBar: AppBar(title: Text(shoppingList.name)),
      body: Center(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: SizedBox(
                width: 200,
                height: 200,
                child: CircleAvatar(
                  radius: 50,
                  child: Text(shoppingList.sum.toString(), style: const TextStyle(fontSize: 30),),
                ),
              ),
            ),
            Text('Product Name : ${shoppingList.name}', style: const TextStyle(fontSize: 16),),
            Text('Total Product : ${shoppingList.sum}', style: const TextStyle(fontSize: 16),),
            // Text('Product Price : ${shoppingList.price}')
          ],
        ),
      ),
    );
  }
}